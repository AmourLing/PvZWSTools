# �����ص�
# �Ӵ浵�ļ��ָ���Ϸ״̬
# 2026.07.27

from Lawn import *
from Sexy import *
from System.IO import *
from LawnMod import MonoModUtils as M

app = GlobalStaticVars.gLawnApp
board = app.mBoard

LoadGame_Name = "game{}_{}.dat".format(int(app.mPlayerInfo.mId), int(app.mGameMode))
LoadGame_Path = Path.Combine(Directory.GetCurrentDirectory(), "docs", "userdata", LoadGame_Name)

if File.Exists(LoadGame_Path):
    board.LoadGame(LoadGame_Path)
else:
    Debug.Log(f"�浵�ļ�������:{LoadGame_Path}")
    pass
